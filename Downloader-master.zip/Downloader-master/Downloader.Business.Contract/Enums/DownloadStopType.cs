﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Toqe.Downloader.Business.Contract.Enums
{
    public enum DownloadStopType
    {
        WithNotification,
        WithoutNotification
    }
}
