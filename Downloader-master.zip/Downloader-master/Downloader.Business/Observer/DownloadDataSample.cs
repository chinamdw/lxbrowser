﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Toqe.Downloader.Business.Observer
{
    public class DownloadDataSample
    {
        public DateTime Timestamp { get; set; }

        public int Count { get; set; }
    }
}